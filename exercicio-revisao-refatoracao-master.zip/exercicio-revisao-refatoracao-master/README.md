# Exercício Pull Request

O objetivo desse problema é praticar a parte de revisão e refatoração.
 
Você deve criar uma cópia local desse repositório, fazer as alterações que julgar necessárias e então realizar um Pull Request. Você é livre para criar outros arquivos, classes, métodos, etc., desde que o main continue produzindo a mesma saída. Lembre-se que essa etapa não altera o comportamento funcional. 
 
No seu pull request faça uma lista/descrição detalhada das possíveis soluções que você utilizou.
  
Dica: Utilize o catálogo com sugestões de refatoração (https://refactoring.com/catalog/).
